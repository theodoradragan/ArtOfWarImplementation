import XCTest

import ArtOfWarMainTests

var tests = [XCTestCaseEntry]()
tests += ArtOfWarMainTests.allTests()
XCTMain(tests)
import XCTest

import ArtOfWarTestTests

var tests = [XCTestCaseEntry]()
tests += ArtOfWarTestTests.allTests()
XCTMain(tests)
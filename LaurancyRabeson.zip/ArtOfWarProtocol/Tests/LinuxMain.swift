import XCTest

import ArtOfWarProtocolTests

var tests = [XCTestCaseEntry]()
tests += ArtOfWarProtocolTests.allTests()
XCTMain(tests)